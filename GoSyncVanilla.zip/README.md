# ENGLISH
# Google Contacts and Calendar Sync Adapters for GApps Zip bundled with GApps Sync Adapters Apps.

This is a Magisk module that contains the required files to be able to sync your Contacts and Calendar from your Google accounts data sync to your device.

For use with GApps Zip bundled with GApps Sync Adapters Apps.


# INDONESIA
# Google Contacts dan Calendar Sync Adapters untuk digunakan dengan GApps Zip yang satu paket dengan Aplikasi GApps Sync Adapters Apps.

Ini adalah modul Magisk/KSU(N) yang berisi file yang diperlukan untuk dapat menyinkronkan data sinkron Kontak dan Kalender dari akun Google Anda ke perangkat Anda.

Untuk digunakan dengan GApps Zip yang satu paket dengan Aplikasi GApps Sync Adapters Apps.

