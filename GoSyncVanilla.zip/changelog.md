### v1.0 - 13.4.2025
* Initial release